import { useState, useRef, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import Header from './components/Header';
import MenuDrawer from './components/MenuDrawer';
import ShowReel from './components/ShowReel';
import { StarsAndDescription, ServicesList } from './components/ServicesSection';
import { HeroTitle } from './components/HeroTitle';
import SplashCursor from './components/SplashCursor';
import ScrollReveal from './components/ScrollReveal';
import ServicesScrollSection from './components/ServicesScrollSection';
import ImageCollageSection from './components/ImageCollageSection';
import SelectedWorkSection from './components/SelectedWorkSection';
import CommitmentSection from './components/CommitmentSection';
import ProjectParallaxPanels from './components/ProjectParallaxPanels';
import PortfolioStorySection from './components/PortfolioStorySection';
import AppleWatchGridSection from './components/applewach';
import Footer from './components/footer';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isHoveringHero, setIsHoveringHero] = useState(false);
  const [isHeroVisible, setIsHeroVisible] = useState(true);

  // Track scroll position of the window
  const { scrollY } = useScroll();

  useEffect(() => {
    const handleScroll = () => {
      setIsHeroVisible(window.scrollY < window.innerHeight);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Create smooth slow-moving parallax translation
  const heroY = useTransform(scrollY, [0, 1000], [0, 320]);

  return (
    <div id="app-container" className="min-h-screen bg-[#e8e0d6] text-[#2c2218] flex flex-col select-none relative overflow-x-clip grain-bg animate-fade-in">
      {/* Grain Overlay - Applied everywhere */}
      <div className="grain-overlay" />

      {/* Menu Drawer */}
      <MenuDrawer isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />

      {/* SECTION 1: HERO (Sticky, slow-moving parallax) */}
      <div 
        onMouseEnter={() => setIsHoveringHero(true)}
        onMouseLeave={() => setIsHoveringHero(false)}
        onMouseMove={() => {
          if (!isHoveringHero) setIsHoveringHero(true);
        }}
        className="relative h-screen w-full overflow-hidden bg-[#e8e0d6] z-10 flex flex-col justify-between"
      >
        {/* Premium organic liquid blob image reveal on cursor (Desktop only, absolute inside Hero section) */}
        <SplashCursor
          DENSITY_DISSIPATION={1.5}
          VELOCITY_DISSIPATION={3}
          PRESSURE={0.55}
          CURL={2}
          SPLAT_RADIUS={0.27}
          SPLAT_FORCE={20000}
          COLOR_UPDATE_SPEED={19}
          SHADING
          RAINBOW_MODE={false}
          position="absolute"
          zIndex={1}
          isActive={isHeroVisible && isHoveringHero}
        />

        <motion.div 
          style={{ y: heroY }} 
          className="h-full w-full flex flex-col justify-between relative z-10"
        >
          {/* Header */}
          <div className="relative z-20">
            <Header onMenuClick={() => setIsMenuOpen(true)} />
          </div>

          {/* DESKTOP LAYOUT (md and up) */}
          <main id="desktop-layout" className="hidden md:flex flex-col flex-grow justify-between max-w-[1340px] w-full mx-auto px-12 lg:px-16 py-12 lg:py-16 relative z-10">
            
            {/* Upper Section (Row 1) - Bottom aligned */}
            <div className="grid grid-cols-12 gap-10 lg:gap-14 items-end mt-4">
              {/* Column 1: Video Card (5/12 width) */}
              <div className="col-span-5">
                <ShowReel />
              </div>

              {/* Column 2: Stars and Description (4/12 width) */}
              <div className="col-span-4 pb-1">
                <StarsAndDescription />
              </div>

              {/* Column 3: Services List (3/12 width) */}
              <div className="col-span-3 pb-1">
                <ServicesList />
              </div>
            </div>

            {/* Thick elegant gap or separator */}
            <div className="w-full my-10 lg:my-14 relative z-20">
              <div className="h-[1px] w-full bg-zinc-300" />
            </div>

            {/* Lower Section (Row 2) - Bottom aligned */}
            <div className="flex justify-between items-end gap-12 pb-4">
              {/* Left: Huge Hero Title */}
              <div>
                <HeroTitle />
              </div>
            </div>

          </main>

          {/* MOBILE LAYOUT (sm / xs) */}
          <main id="mobile-layout" className="flex md:hidden flex-col gap-10 px-6 py-8 flex-grow justify-between relative z-10">
            
            {/* 1. Hero Title at the very top */}
            <div className="mt-2">
              <HeroTitle />
            </div>

            {/* 2. Rating & Description */}
            <div className="mt-2">
              <StarsAndDescription />
            </div>

            {/* 3. Show Reel Video Card */}
            <div className="mt-2 mb-4">
              <ShowReel />
            </div>

          </main>
        </motion.div>
      </div>

      {/* SECTION 2: ABOUT IV CONCEPT (Slides on top of Section 1 with higher z-index) */}
      <section
        className="relative z-40 -mb-12 md:-mb-16 bg-[#121110] min-h-screen text-white flex flex-col justify-center py-24 md:py-32 px-6 md:px-16"
        style={{
          boxShadow: '0 -20px 50px rgba(0, 0, 0, 0.6), 0 20px 50px rgba(0, 0, 0, 0.6)',
        }}
      >
        {/* Subtle decorative grid/border alignment to keep the look clean, architectural and high-end */}
        <div className="max-w-[1140px] w-full mx-auto flex flex-col gap-12 md:gap-16">
          
          {/* Subtitle / Header info */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-6">
            <span className="text-[10px] md:text-xs text-zinc-400 tracking-[0.25em] font-sans font-bold uppercase">
              ABOUT IV CONCEPT
            </span>
            <span className="text-xs md:text-sm text-zinc-500 font-medium tracking-wide">
              Decorative Mirrors • Textured Walls • Roka Finishes
            </span>
          </div>

          {/* Main Title + ScrollReveal Content */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-16 items-start">
            
            {/* Elegant Display Title */}
            <div className="md:col-span-4">
              <h2 className="text-3xl md:text-5xl font-display font-light tracking-tight text-white leading-tight">
                About <br className="hidden md:block" />
                IV Concept
              </h2>
              <div className="h-1 w-12 bg-white mt-6 opacity-30" />
            </div>

            {/* ScrollReveal text description */}
            <div className="md:col-span-8 text-xl md:text-3xl font-light text-zinc-300 leading-relaxed tracking-wide font-sans">
              <ScrollReveal
                baseOpacity={0.1}
                enableBlur
                baseRotation={3}
                blurStrength={4}
              >
                At IV Concept, we transform simple interiors into refined visual experiences. We create decorative mirrors, textured walls and Roka-inspired surfaces designed to bring depth, elegance and personality into every space. Each project is built around detail, proportion and atmosphere — because a wall should not only cover a room, it should define it.
              </ScrollReveal>
            </div>

          </div>

          {/* Minimal design accents at the bottom */}
          <div className="flex justify-between items-center text-[10px] text-zinc-600 font-mono tracking-widest uppercase mt-12 md:mt-24 border-t border-zinc-900 pt-8">
            <span>© 2026 IV Concept</span>
            <span>Architectural Atmosphere & Artistry</span>
          </div>

        </div>
      </section>

      {/* SECTION 3: PORTFOLIO HORIZONTAL COLLAGE */}
      <ImageCollageSection />

      {/* SECTION 4: OUR COMMITMENT TRANSITION SECTION */}
      <CommitmentSection />

      {/* SECTION 5: SELECTED WORK / PROJECTS CAROUSEL */}
      <SelectedWorkSection />

      {/* SECTION 6: SERVICES STACK */}
      <ServicesScrollSection />

      {/* SECTION 7: PARALLAX PROJECT PANELS */}
      <ProjectParallaxPanels />

      {/* SECTION 8: VIKTOR STORY */}
      <PortfolioStorySection />

      {/* SECTION 9: APPLE WATCH HONEYCOMB PORTFOLIO GRID */}
      <AppleWatchGridSection />

      {/* SECTION 10: FOOTER */}
      <Footer />

    </div>
  );
}

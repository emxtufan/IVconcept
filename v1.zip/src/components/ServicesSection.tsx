import { motion } from 'motion/react';
import { DESCRIPTION, TRUSTED_LABEL, SERVICES } from '../data';

export function StarsAndDescription() {
  return (
    <div className="flex flex-col items-start gap-4 w-full relative z-20">
      {/* Stars & Subtitle */}
      <div className="flex flex-col gap-1.5">
        {/* Solid charcoal stars */}
        <div className="text-[#2c2218] text-xs tracking-[0.2em] select-none font-serif">
          ★★★★★
        </div>
        <span className="text-[#2c2218]/80 font-sans tracking-[0.16em] text-[9.5px] font-bold uppercase">
          {TRUSTED_LABEL}
        </span>
      </div>

      {/* Main Description text */}
      <p className="text-[#2c2218] text-[15.5px] leading-relaxed tracking-wide font-sans max-w-[380px] mt-2">
        {DESCRIPTION}
      </p>

      {/* Divider and Action Link */}
      <div className="w-full max-w-[380px] mt-6">
        <div className="h-[1px] w-full bg-zinc-300" />
        
        {/* Hover block for action link */}
        <motion.a
          href="#services"
          className="flex justify-between items-center py-4 text-[#2c2218] hover:opacity-80 transition-opacity cursor-pointer group"
        >
          <span className="text-[11px] font-sans font-bold tracking-[0.18em]">
            EXPLORE SERVICES
          </span>
          <motion.span
            variants={{
              initial: { x: 0 },
              hover: { x: 4 }
            }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            initial="initial"
            whileHover="hover"
            className="flex items-center"
          >
            <svg className="w-4 h-4 text-[#2c2218]" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </motion.span>
        </motion.a>
      </div>
    </div>
  );
}

export function ServicesList() {
  return (
    <div className="flex flex-col items-end justify-end h-full text-right w-full select-none relative z-20">
      <ul className="space-y-2">
        {SERVICES.map((service, index) => (
          <li
            key={index}
            className="text-[#2c2218] hover:opacity-75 transition-opacity duration-300 text-[13.5px] tracking-[0.05em] font-sans font-medium cursor-pointer"
          >
            {service}
          </li>
        ))}
      </ul>
    </div>
  );
}

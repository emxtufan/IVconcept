const STUDIO_LINKS = [
  'Home',
  'About',
  'Services',
  'Work',
  'Journal',
  'Contact',
  '404',
];

const PROJECT_LINKS = [
  'Elm Grove Residence',
  'Noma Kitchen & Bar',
  'Whitehaven Coastal Retreat',
  'Maison Noir Boutique Hotel',
  'Park Lane Penthouse',
  'Arch Studio Office',
];

const SOCIAL_LINKS = ['Instagram', 'Pinterest', 'X (Twitter)', 'LinkedIn', 'Behance'];

const FOOTER_IMAGE =
  'https://images.unsplash.com/photo-1600210492493-0946911123ea?auto=format&fit=crop&w=2200&q=80';

export default function Footer() {
  return (
    <footer className="relative z-40 bg-black text-white">
      <div className="relative overflow-hidden bg-black">
        <div className="relative mx-auto max-w-[1310px] px-6 py-16 md:px-12 md:py-20 xl:px-0">
          <div className="grid gap-x-10 gap-y-14 md:grid-cols-2 lg:grid-cols-[238px_150px_250px_360px] lg:justify-between">
            <div className="space-y-11">
              <div>
                <div className="flex items-center gap-2.5 font-sans text-[16px] font-semibold tracking-[-0.035em] text-white">
                  <span className="inline-block -skew-x-[18deg] tracking-[-0.28em] text-[17px]">
                    ///
                  </span>
                  <span>Avéon</span>
                </div>
                <div className="mt-4 text-[11px] font-semibold uppercase tracking-[-0.01em] text-white/62">
                  INTERIOR DESIGN STUDIO - EST. 2020
                </div>
              </div>

              <div className="space-y-0.5 text-[14px] leading-[1.45] text-white/82">
                <p>123 Design District Brooklyn, NY</p>
                <p>hello@aveondesign.com</p>
                <p>+1 (415) 555-0199</p>
              </div>
            </div>

            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[-0.01em] text-[#c9a277]">
                [ STUDIO ]
              </div>
              <nav className="mt-11 flex flex-col gap-[3px] text-[15px] leading-[1.3] text-white/84">
                {STUDIO_LINKS.map((link) => (
                  <a key={link} href="#" className="w-fit">
                    {link}
                  </a>
                ))}
              </nav>
            </div>

            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[-0.01em] text-[#c9a277]">
                [ PROJECTS ]
              </div>
              <nav className="mt-11 flex flex-col gap-[3px] text-[15px] leading-[1.3] text-white/84">
                {PROJECT_LINKS.map((link) => (
                  <a key={link} href="#" className="w-fit">
                    {link}
                  </a>
                ))}
              </nav>
            </div>

            <div className="max-w-[360px]">
              <h3 className="text-[22px] font-semibold leading-[1.02] tracking-[-0.055em] text-white">
                Get quarterly notes on new work,
                <br />
                materials, and behind-the-scenes
                <br />
                process
              </h3>

              <div className="mt-11">
                <input
                  type="email"
                  placeholder="max@setframe.design"
                  className="h-[42px] w-full border-none bg-[#201b18] px-4 text-[14px] text-white/68 outline-none placeholder:text-white/48"
                />
                <button
                  type="button"
                  className="mt-2 flex w-full items-center justify-between border-t border-white/26 pt-3 text-left text-[14px] font-semibold uppercase tracking-[-0.01em] text-white"
                >
                  <span>SUBSCRIBE NOW</span>
                  <span aria-hidden="true" className="text-[24px] leading-none">
                    →
                  </span>
                </button>
                <p className="mt-11 max-w-[300px] text-[12px] leading-[1.52] text-white/38">
                  No spam. Just honest design thinking delivered to your inbox once a quarter.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/12">
          <div className="relative mx-auto max-w-[1310px] px-6 py-8 md:px-12 xl:px-0">
            <div className="grid grid-cols-2 gap-y-4 text-[15px] text-white/76 sm:grid-cols-3 lg:grid-cols-5 lg:gap-10">
              {SOCIAL_LINKS.map((link) => (
                <a key={link} href="#" className="text-left lg:text-center">
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="relative h-[300px] overflow-hidden">
        <img
          src={FOOTER_IMAGE}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 h-full w-full object-cover"
          referrerPolicy="no-referrer"
        />

        <div className="relative mx-auto flex h-full max-w-[1310px] flex-col px-6 pt-12 md:px-12 md:pt-14 xl:px-0">
          <div className="grid gap-5 text-[14px] text-white/92 md:grid-cols-3 md:items-start">
            <div>© 2026 Aveon Design. All rights reserved.</div>
            <div className="md:text-center">Crafted with care in Brooklyn, NY.</div>
            <div className="flex flex-col gap-1 md:items-end md:text-right">
              <a href="#">Privacy Policy</a>
              <a href="#">Terms &amp; Conditions</a>
            </div>
          </div>

          <div className="relative mt-auto h-[54%] overflow-visible">
            <div className="pointer-events-none absolute bottom-[-0.27em] left-1/2 -translate-x-1/2 whitespace-nowrap font-sans text-[clamp(118px,15vw,292px)] font-semibold leading-none tracking-[-0.095em] text-white/96">
              Avéon Studio
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

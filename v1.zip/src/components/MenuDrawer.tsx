import { motion, AnimatePresence } from 'motion/react';
import { SERVICES } from '../data';

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MenuDrawer({ isOpen, onClose }: MenuDrawerProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.7 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-40 cursor-pointer"
          />

          {/* Drawer Panel */}
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 180 }}
            className="fixed top-0 left-0 bottom-0 w-full max-w-sm bg-[#0a0a0a] border-r border-zinc-900 z-50 p-8 flex flex-col justify-between"
          >
            {/* Top Row: Brand & Close */}
            <div>
              <div className="flex justify-between items-center mb-12">
                <span className="text-white font-sans font-semibold tracking-wider text-sm uppercase">
                  AVÉON DESIGN
                </span>
                <button
                  onClick={onClose}
                  className="p-1 border border-zinc-800 rounded-md hover:border-zinc-500 hover:bg-zinc-900 transition-colors"
                >
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* Navigation Links */}
              <nav className="flex flex-col gap-6">
                <a href="#about" onClick={onClose} className="text-xl text-zinc-400 hover:text-white transition-colors tracking-wide font-medium">
                  About Avéon
                </a>
                <a href="#services" onClick={onClose} className="text-xl text-zinc-400 hover:text-white transition-colors tracking-wide font-medium">
                  Our Services
                </a>
                <a href="#portfolio" onClick={onClose} className="text-xl text-zinc-400 hover:text-white transition-colors tracking-wide font-medium">
                  Portfolio
                </a>
                <a href="#contact" onClick={onClose} className="text-xl text-zinc-400 hover:text-white transition-colors tracking-wide font-medium">
                  Contact Us
                </a>
              </nav>
            </div>

            {/* Bottom Row: Info */}
            <div>
              <span className="text-[10px] text-zinc-500 tracking-widest uppercase block mb-4">
                Available Services
              </span>
              <ul className="space-y-1.5 mb-8">
                {SERVICES.map((srv, idx) => (
                  <li key={idx} className="text-xs text-zinc-400">
                    {srv}
                  </li>
                ))}
              </ul>
              <div className="text-[10px] text-zinc-600 font-mono">
                © 2026 Avéon Design. Brooklyn, NY.
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

import { useRef, useState, useEffect, PointerEvent } from 'react';
import { useScroll } from 'motion/react';

interface CollageImage {
  url: string;
  label: string;
  dimensions: string;
  aspectClass: string;
  heightClass: string;
}

interface CollageColumn {
  id: number;
  images: CollageImage[];
}

const COLLAGE_DATA: CollageColumn[] = [
  {
    id: 1,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1618219908412-a29a1bb7b86e?auto=format&fit=crop&w=1000&q=80',
        label: '[ 01 // TEXTURED SURFACE ]',
        dimensions: 'Plaster & Roka Finish',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1000&q=80',
        label: '[ 02 // TIMBER ACCENTS ]',
        dimensions: 'Warm Walnut Lounge',
        aspectClass: 'aspect-square',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1000&q=80',
        label: '[ 03 // TRAVERTINE PLINTH ]',
        dimensions: 'Curated Object Placement',
        aspectClass: 'aspect-[9/16]',
        heightClass: ''
      }
    ]
  },
  {
    id: 2,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
        label: '[ 04 // BRUTALIST ARCH ]',
        dimensions: 'Raw Plaster Intersection',
        aspectClass: 'aspect-[4/3]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1000&q=80',
        label: '[ 05 // LUXURY MARBLE ]',
        dimensions: 'Deep Vein Dark Stone',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      }
    ]
  },
  {
    id: 3,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1000&q=80',
        label: '[ 06 // TIMELESS SPACES ]',
        dimensions: 'Minimalist Dining Concept',
        aspectClass: 'aspect-[9/16]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1000&q=80',
        label: '[ 07 // REFLECTIVE PLANE ]',
        dimensions: 'Atmospheric Shadow Play',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1000&q=80',
        label: '[ 08 // SOLEMN HALLWAY ]',
        dimensions: 'Symmetric Light Channels',
        aspectClass: 'aspect-square',
        heightClass: ''
      }
    ]
  },
  {
    id: 4,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1000&q=80',
        label: '[ 09 // SCULPTED GEOMETRY ]',
        dimensions: 'Roka-Inspired Columns',
        aspectClass: 'aspect-[4/5]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1556912173-3bb406ef7e77?auto=format&fit=crop&w=1000&q=80',
        label: '[ 10 // ORGANIC LIVING ]',
        dimensions: 'Curated Raw Materials',
        aspectClass: 'aspect-[3/2]',
        heightClass: ''
      }
    ]
  },
  {
    id: 5,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1617806118233-18e1db207faf?auto=format&fit=crop&w=1000&q=80',
        label: '[ 11 // BRONZED GLASS ]',
        dimensions: 'Polished Mirror Partition',
        aspectClass: 'aspect-[9/16]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1615529182906-134856f8fc0a?auto=format&fit=crop&w=1000&q=80',
        label: '[ 12 // MINIMAL KITCHEN ]',
        dimensions: 'Monolithic Stone Island',
        aspectClass: 'aspect-[4/3]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?auto=format&fit=crop&w=1000&q=80',
        label: '[ 13 // OAK CABINETRY ]',
        dimensions: 'Brushed Brass Detailing',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      }
    ]
  },
  {
    id: 6,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80',
        label: '[ 14 // RECESSED COVE ]',
        dimensions: 'Indirect Ambient Glow',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=1000&q=80',
        label: '[ 15 // TACTILE TEXTILES ]',
        dimensions: 'Bouclé & Linen Accents',
        aspectClass: 'aspect-square',
        heightClass: ''
      }
    ]
  },
  {
    id: 7,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=80',
        label: '[ 16 // BEDROOM ARCH ]',
        dimensions: 'Washed Linens & Shadows',
        aspectClass: 'aspect-[4/5]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80',
        label: '[ 17 // STONE BATHROOM ]',
        dimensions: 'Honed Pietra Grey',
        aspectClass: 'aspect-[3/2]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1618219944342-824e40a13285?auto=format&fit=crop&w=1000&q=80',
        label: '[ 18 // TERRACOTTA VASE ]',
        dimensions: 'Raw Clay & Neutral Tones',
        aspectClass: 'aspect-[9/16]',
        heightClass: ''
      }
    ]
  },
  {
    id: 8,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1616046229478-9901c5536a45?auto=format&fit=crop&w=1000&q=80',
        label: '[ 19 // RUSTIC BENCH ]',
        dimensions: 'Curated Wabi Sabi Entry',
        aspectClass: 'aspect-[4/3]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?auto=format&fit=crop&w=1000&q=80',
        label: '[ 20 // SYMMETRIC SINKS ]',
        dimensions: 'Dual Stone Washbasin',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      }
    ]
  },
  {
    id: 9,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1617103996706-09a585a49162?auto=format&fit=crop&w=1000&q=80',
        label: '[ 21 // WARM LUMINESCENCE ]',
        dimensions: 'Soft Recessed Lighting',
        aspectClass: 'aspect-[9/16]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1000&q=80',
        label: '[ 22 // LINEAR VISTA ]',
        dimensions: 'Seamless Horizon Corridor',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1615876234886-fd9a39faa97f?auto=format&fit=crop&w=1000&q=80',
        label: '[ 23 // SCULPTURAL CHAIR ]',
        dimensions: 'Curved Bouclé Lounge',
        aspectClass: 'aspect-square',
        heightClass: ''
      }
    ]
  },
  {
    id: 10,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1600210491892-03d54c0aaf87?auto=format&fit=crop&w=1000&q=80',
        label: '[ 24 // TERRACE VIEW ]',
        dimensions: 'Framed Panoramic Opening',
        aspectClass: 'aspect-[3/2]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&w=1000&q=80',
        label: '[ 25 // SLEEK WARDROBE ]',
        dimensions: 'Smoked Oak Walk-In Closet',
        aspectClass: 'aspect-[4/5]',
        heightClass: ''
      }
    ]
  },
  {
    id: 11,
    images: [
      {
        url: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1000&q=80',
        label: '[ 26 // MONOCHROME SOFTNESS ]',
        dimensions: 'Plaster Bedroom Concept',
        aspectClass: 'aspect-[9/16]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1000&q=80',
        label: '[ 27 // CURATED FIREPLACE ]',
        dimensions: 'Poured Concrete Mantelpiece',
        aspectClass: 'aspect-[3/4]',
        heightClass: ''
      },
      {
        url: 'https://images.unsplash.com/photo-1600121848594-d8644e57abab?auto=format&fit=crop&w=1000&q=80',
        label: '[ 28 // ZEN BALCONY ]',
        dimensions: 'Minimal Outdoor Lounge',
        aspectClass: 'aspect-square',
        heightClass: ''
      }
    ]
  }
];

export default function ImageCollageSection() {
  const targetRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const requestRef = useRef<number | null>(null);

  const isDragging = useRef(false);
  const startX = useRef(0);
  const currentDragOffset = useRef(0);
  const dragStartOffset = useRef(0);

  const velocity = useRef(0);
  const lastTime = useRef(performance.now());
  const lastX = useRef(0);

  const loopWidth = useRef(0);
  const currentX = useRef(0);
  const initialized = useRef(false);
  const lastInteractTime = useRef(performance.now());

  // Track page scroll progress starting earlier when top is 40px from bottom of viewport
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start 0.95", "end start"]
  });

  const updateDimensions = () => {
    if (trackRef.current) {
      loopWidth.current = trackRef.current.scrollWidth / 3;
    }
  };

  // Mathematical modulo wrap function
  const wrap = (value: number, min: number, max: number) => {
    const range = max - min;
    return ((((value - min) % range) + range) % range) + min;
  };

  useEffect(() => {
    if (!trackRef.current) return;

    // Use ResizeObserver to detect when container size changes (e.g. images load, window resizes)
    const observer = new ResizeObserver(() => {
      updateDimensions();
    });
    observer.observe(trackRef.current);

    // Initial calculation
    updateDimensions();

    // Secondary listener for general window loading
    window.addEventListener('load', updateDimensions);

    // Dynamic wheel listener to handle infinite scrolling at the page boundaries
    const handleGlobalWheel = (e: WheelEvent) => {
      if (!targetRef.current) return;
      
      // Check if mouse is within Section 3
      const rect = targetRef.current.getBoundingClientRect();
      const isMouseInSection = (
        rect.top <= window.innerHeight &&
        rect.bottom >= 0
      );

      if (isMouseInSection) {
        const isAtBottom = window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 8;
        const isAtTop = window.scrollY <= 8;

        // If we are at the top or bottom page scroll boundary, divert the mouse scroll wheel into the carousel
        if ((isAtBottom && e.deltaY > 0) || (isAtTop && e.deltaY < 0)) {
          lastInteractTime.current = performance.now();
          currentDragOffset.current -= e.deltaY * 0.7;
          velocity.current = -e.deltaY * 0.7 * 0.15; // Set physics velocity
        }
      }
    };

    window.addEventListener('wheel', handleGlobalWheel, { passive: true });

    return () => {
      observer.disconnect();
      window.removeEventListener('load', updateDimensions);
      window.removeEventListener('wheel', handleGlobalWheel);
    };
  }, []);

  useEffect(() => {
    const tick = () => {
      if (!trackRef.current) {
        requestRef.current = requestAnimationFrame(tick);
        return;
      }

      // Exact width of one set of images
      let L = loopWidth.current;
      if (!L || isNaN(L) || L < 100) {
        L = trackRef.current.scrollWidth / 3;
        if (L && !isNaN(L) && L >= 100) {
          loopWidth.current = L;
        } else {
          requestRef.current = requestAnimationFrame(tick);
          return;
        }
      }

      // 1. Inertia physics decay
      if (!isDragging.current) {
        if (Math.abs(velocity.current) > 0.01) {
          currentDragOffset.current += velocity.current;
          velocity.current *= 0.94; // Premium physical friction drag
        } else {
          velocity.current = 0;
        }

        // 2. Continuous premium ambient drift (slow floating movement)
        // Resume slowly after 1.5s of no user interaction
        if (performance.now() - lastInteractTime.current > 1500) {
          currentDragOffset.current -= 0.45; // Smooth persistent offset drift
        }
      }

      // Scroll-based translation: as user scrolls, move across the loop (reduced factor for premium slow movement)
      const sX = -scrollYProgress.get() * L * 0.35;
      const dX = currentDragOffset.current;
      const tX = sX + dX;

      // Wrap perfectly into the middle repetition copy to allow infinite looping
      const wrappedTargetX = wrap(tX, -2 * L, -L);

      if (!initialized.current) {
        currentX.current = wrappedTargetX;
        initialized.current = true;
      } else {
        // Prevent sliding backwards during seamless wrapping jumps
        const dist = wrappedTargetX - currentX.current;
        if (Math.abs(dist) > L / 2) {
          currentX.current = wrappedTargetX;
        } else {
          // Ultra-smooth premium lerp interpolation (7% per frame for high-end cinematic feel)
          currentX.current += dist * 0.07;
        }
      }

      // Direct hardware-accelerated 3D transform update for max rendering efficiency
      trackRef.current.style.transform = `translate3d(${currentX.current}px, 0, 0)`;

      requestRef.current = requestAnimationFrame(tick);
    };

    requestRef.current = requestAnimationFrame(tick);

    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [scrollYProgress]);

  // Handle pointer drag starts
  const handlePointerDown = (e: PointerEvent) => {
    if (e.button !== 0) return; // Only left click / standard touches
    e.currentTarget.setPointerCapture(e.pointerId);
    isDragging.current = true;
    startX.current = e.clientX;
    lastX.current = e.clientX;
    dragStartOffset.current = currentDragOffset.current;
    velocity.current = 0;
    lastTime.current = performance.now();
    lastInteractTime.current = performance.now();

    if (trackRef.current) {
      trackRef.current.classList.add('dragging');
    }
  };

  // Handle pointer drag moves
  const handlePointerMove = (e: PointerEvent) => {
    if (!isDragging.current) return;
    
    const now = performance.now();
    const dt = Math.max(now - lastTime.current, 1);
    const deltaX = e.clientX - startX.current;
    
    currentDragOffset.current = dragStartOffset.current + deltaX;
    
    // Calculate scroll/drag velocity with respect to frame rate
    velocity.current = ((e.clientX - lastX.current) / dt) * 16;
    
    lastTime.current = now;
    lastX.current = e.clientX;
    lastInteractTime.current = now;
  };

  // Handle pointer drag ends
  const handlePointerUp = (e: PointerEvent) => {
    if (!isDragging.current) return;
    e.currentTarget.releasePointerCapture(e.pointerId);
    isDragging.current = false;
    lastInteractTime.current = performance.now();

    if (trackRef.current) {
      trackRef.current.classList.remove('dragging');
    }
  };

  return (
    <div 
      ref={targetRef} 
      className="relative z-30 min-h-screen select-none pt-24 md:pt-32 pb-0"
      id="portfolio-collage-section"
    >
      {/* Sticky full screen viewport container */}
      <div className="sticky top-0 h-screen w-full overflow-hidden flex flex-col justify-center">
        
        {/* Subtle Section Header */}
      

        {/* Drag target container spanning full screen, using touch-action pan-y to allow vertical page scrolling */}
        <div 
          className="w-full h-screen flex items-center justify-start touch-action-pany cursor-grab active:cursor-grabbing"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          style={{ touchAction: 'pan-y' }}
        >
          <div 
            ref={trackRef} 
            className="w-max flex flex-row gap-0 h-full py-1.5 md:py-3 items-stretch will-change-transform"
          >
            {/* Render 3 identical loops of COLLAGE_DATA to make the infinite cycle seamless */}
            {[0, 1, 2].map((loopIdx) => (
              COLLAGE_DATA.map((column) => (
                <div 
                  key={`${loopIdx}-${column.id}`} 
                  className="w-[72vw] sm:w-[55vw] md:w-[32vw] flex-shrink-0 flex flex-col gap-2 md:gap-4 h-full pr-4 md:pr-8"
                >
                  {column.images.map((img, imgIdx) => (
                    <div 
                      key={imgIdx} 
                      className="group relative flex-1 w-full overflow-hidden  rounded-sm"
                    >
                      {/* Dark overlay that fades on hover */}
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-all duration-500 z-10" />
                      
                      <img 
                        src={img.url} 
                        alt={img.label}
                        draggable="false"
                        onLoad={updateDimensions}
                        className="w-full h-full object-cover grayscale-[25%] group-hover:grayscale-0 scale-100 group-hover:scale-[1.03] transition-all duration-700 ease-out select-none pointer-events-none"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Minimal Meta details inside the image boundary */}
                      <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end text-[10px] tracking-wider font-mono text-zinc-300 drop-shadow-md z-20 opacity-80 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                        <span className="text-[9px] text-zinc-400 backdrop-blur-sm px-2 py-1 rounded hidden sm:inline">
                          {img.dimensions}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ))
            ))}
          </div>
        </div>

        {/* Minimal Footer Accent */}
        {/* <div className="absolute bottom-6 left-6 md:left-16 right-6 md:right-16 flex justify-between items-center text-[9px] text-zinc-400 font-mono tracking-widest uppercase z-40 bg-zinc-950/65 backdrop-blur-md px-4 py-2.5 rounded-lg">
          <span>PORTFOLIO CURATION</span>
          <span>© AVÉON / IV CONCEPT</span>
        </div> */}

      </div>
    </div>
  );
}

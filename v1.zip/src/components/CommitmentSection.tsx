import { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';

export default function CommitmentSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Track scroll progress of this section relative to the viewport
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  // Apply smooth spring physics for a high-end, premium feel
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 60,
    damping: 24,
    restDelta: 0.001
  });

  // Map scroll progress to subtle corner translations (moving outward)
  // At scrollProgress 0.1 (entering viewport), corners are closer to center.
  // By scrollProgress 0.5 (perfectly centered), corners reach their native positions (0).
  const tlX = useTransform(smoothProgress, [0.1, 0.48], [140, 0]);
  const tlY = useTransform(smoothProgress, [0.1, 0.48], [100, 0]);

  const trX = useTransform(smoothProgress, [0.1, 0.48], [-140, 0]);
  const trY = useTransform(smoothProgress, [0.1, 0.48], [100, 0]);

  const blX = useTransform(smoothProgress, [0.1, 0.48], [140, 0]);
  const blY = useTransform(smoothProgress, [0.1, 0.48], [-100, 0]);

  const brX = useTransform(smoothProgress, [0.1, 0.48], [-140, 0]);
  const brY = useTransform(smoothProgress, [0.1, 0.48], [-100, 0]);

  // Subtle scaling and opacity animation for the typography elements
  const labelScale = useTransform(smoothProgress, [0.1, 0.48], [0.94, 1]);
  const labelY = useTransform(smoothProgress, [0.1, 0.48], [20, 0]);
  const labelOpacity = useTransform(smoothProgress, [0.1, 0.42], [0.2, 0.85]);

  const headlineScale = useTransform(smoothProgress, [0.1, 0.48], [0.88, 1]);
  const headlineY = useTransform(smoothProgress, [0.1, 0.48], [35, 0]);
  const headlineOpacity = useTransform(smoothProgress, [0.1, 0.46], [0.1, 1]);

  const dividerScaleWidth = useTransform(smoothProgress, [0.1, 0.48], [0.3, 1]);
  const dividerOpacity = useTransform(smoothProgress, [0.1, 0.45], [0, 1]);

  const pScale = useTransform(smoothProgress, [0.1, 0.48], [0.92, 1]);
  const pY = useTransform(smoothProgress, [0.1, 0.48], [45, 0]);
  const pOpacity = useTransform(smoothProgress, [0.1, 0.48], [0, 0.85]);

  const cornerOpacity = useTransform(smoothProgress, [0.1, 0.42], [0.2, 1]);

  return (
    <section 
      ref={containerRef}
      id="commitment-section"
      className="relative z-40  min-h-screen w-full flex flex-col justify-center items-center px-6 md:px-16 select-none pt-4 md:pt-6 pb-12 md:pb-16 overflow-hidden"
    >
      {/* Subtle Camera-Style Corner Guides with Scroll-Linked Expansion */}
      <motion.div 
        style={{ x: tlX, y: tlY, opacity: cornerOpacity }}
        className="absolute top-8 left-8 sm:top-12 sm:left-12 md:top-16 md:left-16 w-6 h-6 border-t border-l border-[#c5a880]/20 pointer-events-none" 
      />
      <motion.div 
        style={{ x: trX, y: trY, opacity: cornerOpacity }}
        className="absolute top-8 right-8 sm:top-12 sm:right-12 md:top-16 md:right-16 w-6 h-6 border-t border-r border-[#c5a880]/20 pointer-events-none" 
      />
      <motion.div 
        style={{ x: blX, y: blY, opacity: cornerOpacity }}
        className="absolute bottom-8 left-8 sm:bottom-12 sm:left-12 md:bottom-16 md:left-16 w-6 h-6 border-b border-l border-[#c5a880]/20 pointer-events-none" 
      />
      <motion.div 
        style={{ x: brX, y: brY, opacity: cornerOpacity }}
        className="absolute bottom-8 right-8 sm:bottom-12 sm:right-12 md:bottom-16 md:right-16 w-6 h-6 border-b border-r border-[#c5a880]/20 pointer-events-none" 
      />

      {/* Centered content with plenty of negative space */}
      <div className="max-w-[1140px] w-full mx-auto flex flex-col items-center justify-center text-center py-12 md:py-20">
        {/* Small premium section label */}
        <motion.span 
          style={{ scale: labelScale, y: labelY, opacity: labelOpacity }}
          className="text-[10px] md:text-xs text-[#c5a880] tracking-[0.4em] font-sans font-bold uppercase block mb-8 sm:mb-12"
        >
          [ OUR COMMITMENT ]
        </motion.span>
        
        {/* Large Centered Headline - Reduced size by ~20%, light weight, elegant tracking and line height */}
        <motion.h2 
          style={{ scale: headlineScale, y: headlineY, opacity: headlineOpacity }}
          className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-[40px] font-display font-light text-white tracking-widest leading-[1.4] max-w-[750px] mb-8 sm:mb-10"
        >
          Crafting Timeless Interiors,<br />
          Designed To Be Remembered.
        </motion.h2>
        
        {/* Subtle premium divider line with scale animation */}
        <motion.div 
          style={{ scaleX: dividerScaleWidth, opacity: dividerOpacity }}
          className="h-[1px] w-12 bg-[#c5a880]/20 my-4" 
        />
        
        {/* Secondary transition text */}
        <motion.p 
          style={{ scale: pScale, y: pY, opacity: pOpacity }}
          className="text-xs sm:text-sm md:text-base lg:text-lg font-light text-zinc-400 tracking-wider max-w-[550px] mt-4 sm:mt-6 font-sans leading-relaxed"
        >
          Transforming Walls Into Art &amp;<br />
          Spaces Into Lasting Memories.
        </motion.p>
      </div>
    </section>
  );
}

import { useLayoutEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const SERVICE_CARDS = [
  {
    id: 1,
    number: '01',
    title: 'Consultancy',
    description: 'Strategic guidance at every stage of a project.',
    image: '/services/card1.png',
  },
  {
    id: 2,
    number: '02',
    title: 'Architecture',
    description: 'Architecture that balances vision, function, and context.',
    image: '/services/card2.png',
  },
  {
    id: 3,
    number: '03',
    title: 'Interior Design',
    description: 'Interiors shaped by atmosphere and everyday experience.',
    image: '/services/card3.svg',
  },
  {
    id: 4,
    number: '04',
    title: 'Object Design',
    description: 'Custom objects that complete the spatial narrative.',
    image: '/services/card4.svg',
  },
  {
    id: 5,
    number: '05',
    title: 'Done',
    description: 'A refined final result, delivered with precision and attention to detail.',
    image: '/services/card5.png',
  },
];

// Shared card surface: same cream panel, radius, border, padding and shadow.
const CARD_FACE =
  'overflow-hidden rounded-lg border border-black/10 bg-[#e8e0d6] text-[#2c2218] px-6 py-6 shadow-2xl md:px-10 md:py-9';

const FLIP_STAGE_STYLE = {
  perspective: '1600px',
  WebkitPerspective: '1600px',
} as const;

const FLIPPER_STYLE = {
  transformStyle: 'preserve-3d',
  WebkitTransformStyle: 'preserve-3d',
} as const;

const FRONT_FACE_STYLE = {
  backfaceVisibility: 'hidden',
  WebkitBackfaceVisibility: 'hidden',
  transform: 'rotateY(0deg) translateZ(0.1px)',
  WebkitTransform: 'rotateY(0deg) translateZ(0.1px)',
} as const;

const BACK_FACE_STYLE = {
  backfaceVisibility: 'hidden',
  WebkitBackfaceVisibility: 'hidden',
  transform: 'rotateY(180deg) translateZ(0.1px)',
  WebkitTransform: 'rotateY(180deg) translateZ(0.1px)',
} as const;

export default function ServicesScrollSection() {
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const sectionRef = useRef<HTMLElement>(null);
  const flipperRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);

  const lastIndex = SERVICE_CARDS.length - 1;

  useLayoutEffect(() => {
    // Cards dock a fixed gap BELOW the pinned header, whatever its real height,
    // so the first card stops there and never slides up under the header zone.
    const HEADER_GAP = 40;
    const stickyOffset = () =>
      (headerRef.current?.offsetHeight ?? 200) + HEADER_GAP;

    // Expose the offset to CSS (the sticky `top` of every card) and keep it
    // fresh if the header re-wraps (viewport resize, font load).
    let lastOffset = -1;
    const applyOffset = () => {
      const off = stickyOffset();
      if (off === lastOffset) return;
      lastOffset = off;
      sectionRef.current?.style.setProperty('--stack-top', `${off}px`);
      ScrollTrigger.refresh();
    };
    applyOffset();
    const ro = new ResizeObserver(applyOffset);
    if (headerRef.current) ro.observe(headerRef.current);

    let flipTicker: (() => void) | null = null;

    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, index) => {
        if (!card || index === lastIndex) return;

        gsap.to(card, {
          scale: 0.86,
          opacity: 0.14,
          filter: 'blur(8px)',
          ease: 'none',
          scrollTrigger: {
            trigger: card,
            start: () => `top ${stickyOffset()}px`,
            end: () => `bottom ${stickyOffset()}px`,
            scrub: true,
            invalidateOnRefresh: true,
          },
        });
      });

      // Last card only: cinematic, scroll-driven 3D flip.
      // The card first docks under the header showing its FRONT ("05 Done"),
      // holds there clearly for a beat, then rotates slowly to the back.
      // Driven by scroll position (not the card's viewport top, which is frozen
      // while docked), measured from the card's stable layout offset.
      const flipTarget = cardsRef.current[lastIndex];
      const flipper = flipperRef.current;
      if (flipTarget && flipper) {
        const easeInOut = gsap.parseEase('power2.inOut');

        // Self-calibrating dock point: while the card is still approaching (not yet
        // pinned), its live position gives the exact scroll at which it will dock.
        // Progress is then measured from there, so the flip runs during the docked
        // dwell — front held clearly first, then a slow rotation to the back.
        let dockScrollY = Infinity;
        let targetAngle = 0;
        let currentAngle = 0;
        let wasDocked = false;

        const backCards = () =>
          cardsRef.current.filter(
            (c, i): c is HTMLDivElement => Boolean(c) && i !== lastIndex,
          );

        const update = () => {
          const vh = window.innerHeight;
          const offset = stickyOffset();
          const top = flipTarget.getBoundingClientRect().top;
          if (top > offset) {
            // Approaching: record the true scroll position where it will dock.
            dockScrollY = top + window.scrollY - offset;
            targetAngle = 0;
            if (wasDocked) {
              // Scrolled back out of the flip zone: restore the stacked cards
              // to their scrubbed resting opacity.
              backCards().forEach((c) => gsap.set(c, { opacity: 0.14 }));
              wasDocked = false;
            }
          } else {
            wasDocked = true;
            const hold = vh * 0.4; // hold the front ("05 Done") clearly after docking
            const duration = vh * 1.0; // long, unhurried rotation zone
            const p = gsap.utils.clamp(
              0,
              1,
              (window.scrollY - dockScrollY - hold) / duration,
            );
            const eased = easeInOut(p);
            targetAngle = eased * 180;
            // The stacked cards behind dissolve away as the rotation begins, so
            // the flipped card ends up alone, pinned on a clean stage.
            const backOpacity = 0.14 * (1 - Math.min(1, eased * 2));
            backCards().forEach((c) => gsap.set(c, { opacity: backOpacity }));
          }
        };

        // Per-frame lerp toward the scroll target: buttery, cinematic easing that
        // stays smooth even on stepped (wheel) scrolling or fast flicks.
        flipTicker = () => {
          currentAngle += (targetAngle - currentAngle) * 0.08;
          gsap.set(flipper, { rotateY: currentAngle, force3D: true });
        };
        gsap.ticker.add(flipTicker);

        // Trigger on the whole section so onUpdate fires across the docked dwell.
        ScrollTrigger.create({
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          onUpdate: update,
          onRefresh: update,
        });
      }
    }, sectionRef);

    return () => {
      ro.disconnect();
      if (flipTicker) gsap.ticker.remove(flipTicker);
      ctx.revert();
    };
  }, [lastIndex]);

  const cardInner = (service: (typeof SERVICE_CARDS)[number]) => (
    <div className="relative z-10 flex min-h-[22rem] md:min-h-[24rem] flex-col justify-between gap-8">
      <div className="flex items-center justify-between gap-4 border-b border-[#2c2218]/10 pb-4">
        <span className="text-[10px] md:text-xs text-[#a07f4f] tracking-[0.3em] font-sans font-bold uppercase">
          Service {service.number}
        </span>
        <span className="text-[10px] text-[#2c2218]/40 font-mono tracking-widest uppercase">
          IV Concept
        </span>
      </div>

      <div className="flex flex-1 items-center justify-center py-2">
        <img
          src={service.image}
          alt={service.title}
          className="h-28 w-auto object-contain md:h-40"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-10 items-end">
        <div className="md:col-span-7">
          <h3 className="text-3xl md:text-5xl font-display font-light tracking-tight text-[#2c2218] leading-tight">
            {service.number} {service.title}
          </h3>
        </div>

        <div className="md:col-span-5">
          <p className="text-sm md:text-base font-light text-[#2c2218]/60 tracking-wide leading-relaxed">
            {service.description}
          </p>
        </div>
      </div>
    </div>
  );

  const renderCard = (service: (typeof SERVICE_CARDS)[number], index: number) => (
    <div
      key={service.id}
      ref={(el) => {
        cardsRef.current[index] = el;
      }}
      className={`sticky w-full max-w-4xl origin-top ${CARD_FACE}`}
      style={{ top: 'var(--stack-top, 240px)' }}
    >
      {cardInner(service)}
    </div>
  );

  const renderFlipCard = (service: (typeof SERVICE_CARDS)[number], index: number) => (
    <div
      key={service.id}
      ref={(el) => {
        cardsRef.current[index] = el;
      }}
      className="mt-[35vh] md:mt-[45vh] sticky w-full max-w-4xl"
      style={{ top: 'var(--stack-top, 240px)', ...FLIP_STAGE_STYLE }}
    >
      <div
        ref={flipperRef}
        className="relative w-full will-change-transform"
        style={FLIPPER_STYLE}
      >
        {/* FRONT — the existing "05 Done" card */}
        <div className={CARD_FACE} style={FRONT_FACE_STYLE}>
          {cardInner(service)}
        </div>

        {/* BACK — same card design, contact message */}
        <div
          className={`absolute inset-0 ${CARD_FACE}`}
          style={BACK_FACE_STYLE}
        >
          <div className="relative z-10 flex min-h-[22rem] md:min-h-[24rem] flex-col justify-between gap-8">
            <div className="flex items-center justify-between gap-4 border-b border-[#2c2218]/10 pb-4">
              <span className="text-[10px] md:text-xs text-[#a07f4f] tracking-[0.3em] font-sans font-bold uppercase">
                Contact
              </span>
              <span className="text-[10px] text-[#2c2218]/40 font-mono tracking-widest uppercase">
                IV Concept
              </span>
            </div>

            <div className="flex flex-1 items-center justify-center py-2">
              <span className="font-display text-6xl md:text-7xl font-light text-[#2c2218]/15">
                &rarr;
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-10 items-end">
              <div className="md:col-span-7">
                <h3 className="text-3xl md:text-5xl font-display font-light tracking-tight text-[#2c2218] leading-tight">
                  Contactează-ne
                </h3>
              </div>

              <div className="md:col-span-5">
                <p className="text-sm md:text-base font-light text-[#2c2218]/60 tracking-wide leading-relaxed">
                  Hai să transformăm spațiul tău într-un proiect memorabil.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <section
      ref={sectionRef}
      id="services"
      className="relative z-30 -mb-[100vh] bg-[#0A0D11] text-white px-6 md:px-16 py-24 md:py-32 border-t border-zinc-900"
    >
      <div className="max-w-[1140px] w-full mx-auto">
        <div
          ref={headerRef}
          className="sticky top-0 z-30 bg-[#0A0D11] pt-6 flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-zinc-900 pb-6"
        >
          <div>
            <span className="text-[10px] md:text-xs text-[#c5a880] tracking-[0.25em] font-sans font-bold uppercase block mb-3">
              [ SERVICES ]
            </span>
            <h2 className="text-3xl md:text-5xl font-display font-light tracking-tight text-white leading-tight">
              Strategic Thinking,
              <br className="hidden sm:block" /> Spatial Precision
            </h2>
          </div>

          <p className="max-w-[420px] text-xs md:text-sm text-zinc-500 font-medium tracking-wide leading-relaxed">
            A vertical sticky stack that reveals each service with measured pace, clean overlap
            and the same quiet material tension used across the rest of the site.
          </p>
        </div>

        <div className="mt-16 md:mt-20 flex flex-col items-center gap-10 md:gap-20">
          {SERVICE_CARDS.map((service, index) =>
            index === lastIndex ? renderFlipCard(service, index) : renderCard(service, index),
          )}
          {/* Real spacer (not padding) gives the last sticky card its scroll range.
              Long enough to host the front hold + slow flip + a clear pinned rest,
              and to keep the card docked while the NEXT section (higher z-index,
              pulled up by the section's -mb-[100vh]) slides over it — so the card
              never scrolls up under the header. */}
          <div aria-hidden className="h-[320vh] w-full shrink-0" />
        </div>
      </div>
    </section>
  );
}

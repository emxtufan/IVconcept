import { useState, useEffect } from 'react';
import { BRAND_LOCATION } from '../data';

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDate = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };
    return date.toLocaleDateString('en-US', options);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  return (
    <header className="w-full">
      {/* Desktop Header */}
      <div className="hidden md:flex justify-between items-center w-full py-6 px-8 md:px-12 border-b border-zinc-300 relative z-20">
        {/* Left: Menu button */}
        <div className="w-1/4 flex justify-start">
          <button
            id="desktop-menu-btn"
            onClick={onMenuClick}
            className="flex items-center justify-center w-11 h-8 border border-zinc-300/80 rounded-md hover:border-zinc-500 hover:bg-zinc-100 transition-all cursor-pointer"
            aria-label="Open menu"
          >
            <svg className="w-4 h-4 text-[#2c2218]" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        {/* Center-Left: Location */}
        <div className="w-1/4 text-center">
          <span className="text-[#2c2218] font-sans tracking-[0.18em] text-[11px] font-semibold uppercase">
            {BRAND_LOCATION}
          </span>
        </div>

        {/* Center-Right: Date */}
        <div className="w-1/4 text-center">
          <span className="text-[#2c2218] font-sans tracking-wide text-[11px] font-semibold">
            {formatDate(time)}
          </span>
        </div>

        {/* Right: Real-time clock */}
        <div className="w-1/4 flex justify-end">
          <span className="text-[#2c2218] font-mono tracking-widest text-[11px] font-bold">
            {formatTime(time)}
          </span>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="flex md:hidden justify-between items-center w-full py-5 px-6 border-b border-zinc-900/10">
        {/* Combined Menu + Brand Slash Button */}
        <button
          id="mobile-menu-btn"
          onClick={onMenuClick}
          className="flex items-center gap-2.5 pl-3 pr-4 py-1.5 border border-zinc-300/80 rounded-lg hover:border-zinc-400 transition-all cursor-pointer bg-transparent relative z-20"
        >
          {/* Burger lines */}
          <svg className="w-4 h-4 text-[#2c2218]" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>

          {/* Vertical Separator */}
          <div className="h-3.5 w-[1px] bg-zinc-300"></div>

          {/* Three Slanted Slashes SVG */}
          <svg className="w-4 h-3 text-[#2c2218] fill-current" viewBox="0 0 20 16">
            <path d="M 2 16 L 6 0 H 8 L 4 16 Z" />
            <path d="M 7 16 L 11 0 H 13 L 9 16 Z" />
            <path d="M 12 16 L 16 0 H 18 L 14 16 Z" />
          </svg>
        </button>

        {/* Right: Real-time Clock */}
        <div className="relative z-20">
          <span className="text-[#2c2218] font-mono tracking-widest text-xs font-semibold">
            {formatTime(time)}
          </span>
        </div>
      </div>
    </header>
  );
}

const founderQuote =
  'My portfolio is where Viktor shapes clean visuals and digital stories that feel personal, purposeful, and built to leave a lasting impact.';

const storyParagraphOne =
  'Built with intention, my portfolio grew from a simple belief: strong visuals start with clarity. I craft each detail to show how ideas move, feel, and connect online.';

const storyParagraphTwo =
  'Every project is personal - shaped by curiosity, craft, and a commitment to web work that feels timeless and built to last.';

const portfolioVideoUrl =
  'https://framerusercontent.com/assets/VqS0xQjmIM5zBg5W2i6Ic5OCcg.mp4';

export default function PortfolioStorySection() {
  return (
    <section className="relative z-40 border-t border-white/10 bg-black text-white">
      <div className="mx-auto max-w-[1600px] px-6 py-20 md:px-12 md:py-24 xl:px-16 xl:py-28">
        <div className="grid gap-10 md:grid-cols-[220px_minmax(0,1fr)] md:gap-16 xl:grid-cols-[280px_minmax(0,1fr)]">
          <div className="pt-2 md:pt-4">
            <span className="block font-sans text-[12px] font-semibold uppercase tracking-[0.08em] text-white/82">
              [ VIKTOR&apos;S STORY ]
            </span>
          </div>

          <div className="max-w-[1180px]">
            <h2 className="font-sans text-[30px] font-semibold leading-[0.96] tracking-[-0.055em] text-white/96 sm:text-[40px] md:text-[54px] lg:text-[68px] xl:text-[78px]">
              <span className="mr-[0.02em] inline-block align-top">&quot;</span>
              {founderQuote}
              <span className="inline-block align-top">&quot;</span>
            </h2>

            <div className="mt-10 flex items-center gap-4 md:mt-12">
              <div className="h-14 w-14 rounded-[10px] border border-white/35 sm:h-16 sm:w-16" />
              <div className="min-w-0">
                <div className="font-sans text-[15px] font-semibold uppercase tracking-[-0.02em] text-white">
                  VIKTOR DESIGN
                </div>
                <div className="mt-1 font-sans text-[12px] font-medium uppercase tracking-[0.02em] text-white/72 sm:text-[13px]">
                  DESIGN DIRECTION &amp; FRONTEND
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-20 border-t border-white/10 pt-14 md:mt-24 md:pt-20">
          <div className="grid gap-12 md:grid-cols-[220px_minmax(0,1fr)] md:gap-16 xl:grid-cols-[280px_minmax(0,1fr)]">
            <div className="flex items-start">
              <span className="font-sans text-[56px] font-semibold leading-none tracking-[-0.2em] text-white/96 sm:text-[68px]">
                ///
              </span>
            </div>

            <div className="grid items-start gap-10 lg:grid-cols-[minmax(0,610px)_minmax(320px,1fr)] lg:gap-12 xl:grid-cols-[minmax(0,610px)_460px] xl:gap-16">
              <div className="max-w-[610px]">
                <h3 className="font-sans text-[42px] font-semibold leading-[0.95] tracking-[-0.05em] text-white sm:text-[48px] md:text-[56px]">
                  My Story.
                </h3>

                <p className="mt-10 font-sans text-[23px] font-normal leading-[1.22] tracking-[-0.035em] text-white/94 sm:text-[26px] md:mt-12 md:text-[30px]">
                  {storyParagraphOne}
                </p>

                <p className="mt-8 font-sans text-[23px] font-normal leading-[1.22] tracking-[-0.035em] text-white/94 sm:text-[26px] md:text-[30px]">
                  {storyParagraphTwo}
                </p>

                <button
                  type="button"
                  className="mt-12 flex w-full max-w-[320px] items-center justify-between border-t border-white/22 pt-5 text-left font-sans text-[15px] font-semibold uppercase tracking-[0.02em] text-white/95"
                >
                  <span>VIEW WORKS</span>
                  <span aria-hidden className="text-[28px] leading-none">
                    →
                  </span>
                </button>
              </div>

              <div className="w-full max-w-[460px] justify-self-start lg:justify-self-end">
                <div className="group relative aspect-square w-full overflow-hidden border border-white/16 bg-[#050505]">
                  <video
                    autoPlay
                    loop
                    muted
                    playsInline
                    preload="auto"
                    className="absolute inset-0 h-full w-full object-cover opacity-88 transition-transform duration-700 group-hover:scale-[1.02]"
                  >
                    <source src={portfolioVideoUrl} type="video/mp4" />
                  </video>
                  <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgba(0,0,0,0.14)_0%,rgba(0,0,0,0.05)_38%,rgba(0,0,0,0.34)_100%)]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

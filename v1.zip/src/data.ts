// Static content for Avéon Landing Page

export const SERVICES = [
  "Residential Design",
  "Commercial Interiors",
  "Furniture Curation",
  "Spatial Planning"
];

export const DESCRIPTION = "Transform your space into an Avéon where luxury meets livability through timeless design excellence.";

export const TRUSTED_LABEL = "TRUSTED BY 200+ HOMEOWNERS";

export const WELCOME_LABEL = "[ WELCOME TO AVÉON ]";

export const BRAND_LOCATION = "BROOKLYN - NEW YORK";
